begin;
-- Personal theme editor from the shared site.
create table if not exists public.jfl_user_themes(
 user_id uuid primary key references auth.users(id) on delete cascade,
 primary_color text not null,secondary_color text not null,tertiary_color text not null,
 updated_at timestamptz not null default now());
alter table public.jfl_user_themes enable row level security;
drop policy if exists jfl_theme_owner on public.jfl_user_themes;
create policy jfl_theme_owner on public.jfl_user_themes for all to authenticated
 using(user_id=auth.uid()) with check(user_id=auth.uid());
grant select,insert,update on public.jfl_user_themes to authenticated;
-- Match moderation, private vote register and daily cards.
grant delete on public.match_chat,public.jfl_comments to authenticated;
drop policy if exists jfl_chat_admin_delete on public.match_chat;
create policy jfl_chat_admin_delete on public.match_chat for delete to authenticated using(public.jfl_admin());
drop policy if exists jfl_comment_admin_delete on public.jfl_comments;
create policy jfl_comment_admin_delete on public.jfl_comments for delete to authenticated using(public.jfl_admin());
drop policy if exists jfl_admin_vote_register on public.league_votes;
create policy jfl_admin_vote_register on public.league_votes for select to authenticated using(public.jfl_admin());
create table if not exists public.jfl_daily_cards(
 owner uuid not null references auth.users(id) on delete cascade,day date not null,
 player text not null,edition text not null, primary key(owner,day));
alter table public.jfl_daily_cards enable row level security;
revoke all on public.jfl_daily_cards from public,anon,authenticated;
grant select on public.jfl_daily_cards to authenticated;
drop policy if exists jfl_read_collection on public.jfl_daily_cards;
create policy jfl_read_collection on public.jfl_daily_cards for select to authenticated using(owner=auth.uid());
create or replace function public.jfl_open_pack() returns jsonb
language plpgsql security definer set search_path='' as $$
declare
 account uuid:=auth.uid();
 today date:=(now() at time zone 'America/Toronto')::date;
 chosen text; roll float:=random(); result public.jfl_daily_cards;
begin
 if account is null then raise exception 'Sign in to open a pack'; end if;
 select candidate into chosen from (
 select distinct trim(p->>'n') candidate from public.games g
 cross join lateral jsonb_array_elements(g.teams::jsonb) t
 cross join lateral jsonb_array_elements(t->'players') p
 where coalesce(trim(p->>'n'),'')<>'' and upper(trim(p->>'n')) not in ('N/A','NA')
 ) roster order by random() limit 1;
 if chosen is null then raise exception 'Log a match before opening cards';end if;
 insert into public.jfl_daily_cards values(account,today,chosen,case when roll<0.01 then 'Signature' when roll<0.07 then 'Prismatic' when roll<0.30 then 'Foil' else 'Base' end)
 on conflict(owner,day) do nothing;
 select * into strict result from public.jfl_daily_cards where owner=account and day=today;
 return to_jsonb(result)-'owner';
end $$;
revoke all on function public.jfl_open_pack() from public,anon;
grant execute on function public.jfl_open_pack() to authenticated;
commit;
